package threeadd.glimpsy.util.manager;

public abstract class Manager {

    public void enable() {}

    public void disable() {}
}
