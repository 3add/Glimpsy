package threeadd.glimpsy.util;

import net.kyori.adventure.text.Component;

public interface Documentable {
    Component createUsage();
}
